<?php
// Heading
$_['heading_title']            = '[OCN] FileManager elFinder';

// Text
$_['text_extension']           = 'Extensions';
$_['text_success']             = 'Success: You have modified FileManager elFinder!';
$_['text_edit']                = 'Edit FileManager elFinder';

// Entry
$_['entry_status']             = 'Status module';
$_['entry_product_status']     = 'Status module in products';
$_['entry_category_status']    = 'Status module in category';
$_['entry_information_status'] = 'Status module in information';
$_['entry_html_status']        = 'Status module in html-content';
$_['entry_marketing_status']   = 'Status module marketing mail';

// Error
$_['error_permission']         = 'Warning: You do not have permission to modify FileManager elFinder!';
