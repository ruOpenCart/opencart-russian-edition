<?php
// Heading
$_['heading_title']            = '[OCN] Менеджер файлов elFinder';

// Text
$_['text_extension']           = 'Расширения';
$_['text_success']             = 'Успешно: Вы изменили модуль менеджера файлов!';
$_['text_edit']                = 'Редактировать модуль Менеджер Файлов';

// Entry
$_['entry_status']             = 'Статус модуля';
$_['entry_product_status']     = 'Статус модуля в товарах';
$_['entry_category_status']    = 'Статус модуля в категориях';
$_['entry_information_status'] = 'Статус модуля в информации';
$_['entry_html_status']        = 'Статус модуля в html-содержимом';
$_['entry_marketing_status']   = 'Статус модуля в рассылке маркетинга';

// Error
$_['error_permission']         = 'Предупреждение: У Вас нет прав на изменение модуля менеджера файлов!';
