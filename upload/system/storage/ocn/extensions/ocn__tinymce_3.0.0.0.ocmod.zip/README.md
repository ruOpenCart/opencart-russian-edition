# TinyMCE 5 Community

Редактор TinyMCE для opencart.

## Описание

Заменяет встроенный редактор summernote на TinyMCE на страницах:
- admin/view/template/catalog/category_form.twig
- admin/view/template/catalog/product_form.twig
- admin/view/template/catalog/information_form.twig
- admin/view/template/marketing/contact.twig
- admin/view/template/extension/module/html.twig

Языки:
- English
- Русский


### Совместимость
- OpenCart 3.0.3.x

## Ссылки
- [Расширение на форуме](https://forum.opencart.name/resources/)