<?php
// Button
$_['button_show_hide'] = 'Показать подкатегории';

// Text
$_['text_show']        = 'Показать подкатегории';
$_['text_hide']        = 'Скрыть подкатегории';
