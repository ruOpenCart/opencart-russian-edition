<?php
// Button
$_['button_show_hide'] = 'Show Subcategories';

// Text
$_['text_show']        = 'Show Subcategories';
$_['text_hide']        = 'Hide Subcategories';
